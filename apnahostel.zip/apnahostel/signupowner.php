<!-- <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apna Login</title>
</head>
<body>
    
</body>
</html> -->
<!DOCTYPE html>
<html>
<style>
	/*set border to the form*/
	
	form {
		border: 3px solid #f1f1f1;
	}
	/*assign full width inputs*/
	
	input[type=text],
	input[type=password] {
		width: 100%;
		padding: 12px 20px;
		margin: 8px 0;
		display: inline-block;
		border: 1px solid #ccc;
		box-sizing: border-box;
	}
	/*set a style for the buttons*/
	
	button {
		background-color: #4CAF50;
		color: white;
		padding: 14px 20px;
		margin: 8px 0;
		border: none;
		cursor: pointer;
		width: 100%;
	}
	/* set a hover effect for the button*/
	
	button:hover {
		opacity: 0.8;
	}
	/*set extra style for the cancel button*/
	
	.cancelbtn {
		width: auto;
		padding: 10px 18px;
		background-color: #f44336;
	}
	/*centre the display image inside the container*/
	
	.imgcontainer {
		text-align: center;
		margin: 24px 0 12px 0;
	}
	/*set image properties*/
	
	img.avatar {
		width: 40%;
		border-radius: 50%;
	}
	/*set padding to the container*/
	
	.container {
		padding: 16px;
	}
	/*set the forgot password text*/
	
	span.psw {
		float: right;
		padding-top: 16px;
	}
	/*set styles for span and cancel button on small screens*/
	
	@media screen and (max-width: 300px) {
		span.psw {
			display: block;
			float: none;
		}
		.cancelbtn {
			width: 100%;
		}
	}
</style>

<body>

	<h2>Sign Up Form</h2>
	<!--Step 1 : Adding HTML-->
	<form action="/action_page.php">
		

		<div class="container">
			<label><b>NAME OF THE OWNER</b></label>
			<input type="text" placeholder="Enter Username" name="uname" required>

			<label><b>NAME OF TH HOSTEL</b></label>
			<input type="text" placeholder="Enter hostel name" name="uname" required>

			<label><b>ADRESS</b></label>
			<input type="text" placeholder="Enter adress" name="uname" required>

			<label><b>AADHAR</b></label>
			<input type="text" placeholder="aadhar number" name="uname" required>

			<label><b>MOBILE NUMBER</b></label>
			<input type="text" placeholder="mobile number" name="uname" required>

			<label><b>EMAIL ADRESS</b></label>
			<input type="text" placeholder="email id" name="uname" required>

			<label><b>CREATE PASSWORD</b></label>
			<input type="text" placeholder="create password" name="uname" required>


 
			<label><b>CONFORM PASSWORD</b></label>
			<input type="password" placeholder="conform password" name="psw" required>

			
			<button type="submit"> <a class="b tn btn-primary  read_more bounceInLeft" data-animation="animated bounceInLeft" href="owner.php">
sign up
			</a> </button>
			<input type="checkbox" checked="checked"> Remember me
		</div>

		<div class="container" style="background-color:#f1f1f1">
			<button type="button" class="cancelbtn">Cancel</button>
			<span class="psw">Forgot <a href="#">password?</a></span>
		</div>
	</form>

</body>

</html>
