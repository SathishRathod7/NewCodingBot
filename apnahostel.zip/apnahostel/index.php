<!DOCTYPE html>
<html lang="en">
   <head>
      <!-- basic -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title>Hostel Management</title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- bootstrap css -->
      <link rel="stylesheet" href="css/bootstrap.min.css">
      <!-- style css -->
      <link rel="stylesheet" href="css/style.css">
      <!-- Responsive-->
      <link rel="stylesheet" href="css/responsive.css">
      <!-- fevicon -->
      <link rel="icon" href="images/fevicon.png" type="image/gif" />
      <!-- Scrollbar Custom CSS -->
      <link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
      <link rel="stylesheet" href="css/owl.carousel.min.css">
      <!-- Tweaks for older IEs-->
      <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
      <link rel="stylesheet" href="https://rawgit.com/LeshikJanz/libraries/master/Bootstrap/baguetteBox.min.css">
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
   </head>
   <!-- body -->
   <body class="main-layout">
      <!-- loader  -->
      <div class="loader_bg">
         <div class="loader"><img src="images/loading.gif" alt="#"/></div>
      </div>
      <!-- end loader -->
      <!-- header -->
      <div class="header">
         <div class="container-fluid">
            <div class="row d_flex">
               <div class="col-xl-1 col-lg-3 col-sm-2 col logo_section">
                  <div class="full">
                     <div class="center-desk">
                        <div class="logo">
                           <a href="index.php">Hostel Management</a>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-xl-7 col-lg-9 col-md-10 col-sm-12">
                  <nav class="navigation navbar navbar-expand-md navbar-dark ">
                     <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample04" aria-controls="navbarsExample04" aria-expanded="false" aria-label="Toggle navigation">
                     <span class="navbar-toggler-icon"></span>
                     </button>
                     <div class="collapse navbar-collapse" id="navbarsExample04">
                        <ul class="navbar-nav mr-auto">
                           <li class="nav-item active">
                              <a class="nav-link" href="index.php">Home</a>
                           </li>
                           <li class="nav-item">
                              <a class="nav-link" href="about.php">About</a>
                           </li>
                           <li class="nav-item">
                              <a class="nav-link" href="service.php">Service</a>
                           </li>
                           <li class="nav-item">
                              <a class="nav-link" href="testimonial.php">We Accommodate</a>
                           </li>
                           <li class="nav-item">
                              <a class="nav-link" href="blog.php">testimonial</a>
                           </li>
                           <li class="nav-item">
                              <a class="nav-link" href="contact.php">Contact Us</a>
                           </li>
                           <li class="nav-item">
                              <a class="nav-link" style="background: transparent;" href="Javascript:void(0)"><i class="fa fa-search"></i></a>
                           </li>
                        </ul>
                     </div>
                  </nav>
               </div>
               <div class="col-md-4 re_no">
                  <ul class="infomaco">
                     <li><i class="fa fa-phone" aria-hidden="true"></i> +91 8340023470</li>
                     <li><a href="Javascript:void(0)"><i class="fa fa-envelope-o" aria-hidden="true"></i> sunilmaug@gmail.com</a></li>
                  </ul>
               </div>
            </div>
         </div>
      </div>
      <!-- end header inner -->
      <!-- end header -->
      <!-- top -->
      <div class="full_bg">
         <div class="slider_main">
            <div class="container-fluid">
               <div class="row">
                  <div class="col-md-12">
                     <!-- carousel code -->
                     
                        <ol class="carousel-indicators">
                           <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                           <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                           <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                        </ol>
                        <div class="carousel-inner">
                           <!-- first slide -->
                           <div class="carousel-item active">
                              <div class="carousel-caption relative">
                                 <div class="row d_flex">
                                    <div class="col-md-5">
                                       <div class="zon_text">
                                          <h1 data-animation="animated bounceInLeft">
                                             Apna<br>
                                             Hostel
                                          </h1>
                                          <p data-animation="animated bounceInLeft">
                                             There are many variations of passages of Loremalteration in some form, by injected humour, or randomised 
                                          </p>
                                          <a class="b tn btn-primary  read_more bounceInLeft" data-animation="animated bounceInLeft" href="owner.php">Owner

                                          </a>
                                          <a class="b tn btn-primary  read_more bounceInLeft" data-animation="animated bounceInLeft" href="student.php">Student

                                          </a>
                                          
                                          <!-- <button class="btn btn-primary  read_more bounceInLeft" data-animation="animated bounceInLeft">Sign up</button> -->
                                       </div>
                                    </div>
                                    <div class="col-md-7">
                                       <div class="coff_img">
                                          <figure><img src="https://abrokenbackpack.com/wp-content/uploads/2017/07/czech-inn-1.jpg" alt="#"/></figure>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           
                           
                        <!-- controls -->
                        
                     </div>
                  
               </div>
            </div>
         </div>
      </div>
      <!-- end banner -->
      <!-- about -->
      <div class="about">
         <div class="container">
            <div class="row d_flex grid">
               <div class="col-md-6">
                  <div class="about_img text_align_center">
                     <figure><img src="https://s3-eu-west-1.amazonaws.com/hc-pages-new/en_11-questions-about-hostels-that-you-have-been-too-embarrassed-to-ask/filepict-1554210442.jpg" alt="#"/></figure>
                  </div>
               </div>
               <div class="col-md-6 order1">
                  <div class="titlepage text_align_left">
                     <h2>About our hostels</h2>
                     <p> the hostel concept has reached nearly every corner of the world, there are still many people who don’t know for certain how to explain what a hostel even is and a prejudice still exists for this style of accommodation.  
                     </p>
                     <a class="read_more" href="about.html">Read More</a>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- end about -->
      <!-- service -->
      <div class="service">
         <div class="container-fluid">
            <div class="row">
               <div class="col-md-12">
                  <div class="titlepage text_align_center">
                     <h2>Hostel Services</h2>
                     <p>we love hostels so much that we believe staying in an epic hostel should be on everyone’s bucket list.
                     </p>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-md-12">
                  <!--  Demos -->
                  <div class="owl-carousel owl-theme">
                     <div class="item">
                        <div class="service_box text_align_center">
                           <div class="ser_img">
                              <figure><img src="https://hostelmanagement.com/sites/default/files/hostel-management-title-%20logo.png" alt="#"/></figure>
                           </div>
                           <h3>Management</h3>
                           <p>Many desktop publishing packages and
                              web page editors 
                           </p>
                        </div>
                     </div>
                     <div class="item">
                        <div class="service_box text_align_center">
                           <div class="ser_img">
                              <figure><img src="https://thumbs.dreamstime.com/b/hotel-staff-room-cleaning-housekeeping-service-female-worker-towels-front-maid-making-bed-62750220.jpg" alt="#"/></figure>
                           </div>
                           <h3>Room cleaning</h3>
                           <p>Many desktop publishing packages and
                              web page editors 
                           </p>
                        </div>
                     </div>
                     <div class="item">
                        <div class="service_box text_align_center">
                           <div class="ser_img">
                              <figure><img src="https://th.bing.com/th/id/R.8f8ed6890cbfac6d9a819aee087c0310?rik=D%2b%2bV7h%2fGnXiK7Q&riu=http%3a%2f%2f2.bp.blogspot.com%2f_NJ6uGHKbtOI%2fTSM2hcr7kvI%2fAAAAAAAAACk%2feFrEjHXeXq0%2fs1600%2f46019-prefer_dining_rarely_enter_grocery_store.jpg&ehk=N2k77GwxjeSOQnPdh%2bi8FiSjddr%2bxydwvcGoKCzv8vU%3d&risl=&pid=ImgRaw&r=0" alt="#"/></figure>
                           </div>
                           <h3>Food service</h3>
                           <p>Many desktop publishing packages and
                              web page editors 
                           </p>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-md-12">
                  
               </div>
            </div>
         </div>
      </div>
      <!-- end service -->
      <!-- section blue_bg -->
      
      <!-- Javascript files-->
      <script src="js/jquery.min.js"></script>
      <script src="js/bootstrap.bundle.min.js"></script>
      <script src="js/jquery-3.0.0.min.js"></script>
      
     <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.8.1/baguetteBox.min.js"></script>
      <script src="js/owl.carousel.min.js"></script>
      <script src="js/custom.js"></script>
   </body>
</html>