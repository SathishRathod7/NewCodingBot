
                <html>
                    <head>
                      <title>studentpage</title>
                      <style>
                        #boxes {
                          content: "";
                          display: table;
                          clear: both;
                        }
                        div {
                          float: left;
                          height: 400px ;
                          
                          width: 33.3%;
                        }
                        #column1 {
                          background-color: #a1edcc;
                        }
                        #column2 {
                          background-color: #a0e9ed;
                          width: 30%;
                        }
                        #column3 {
                          background-color: #f497f1;
                        }
                        h2 {
                          color: #000000;
                          text-align: center;
                        }
                      </style>
                    </head>
                    <body style="margin-left: 5%; margin-right: 5%;">
                      <main id="boxes" >
                        <h2>APNA HOSTEL</h2>
                        <div id="column1">
                          <h2>BOYS HOSTEL</h2> 
                          <a href="#"><img style="height: 80%; width: 100%;" src="images/harshasai3.jpg" class="card-img-top" style="height: 58mm; width: 200;" alt="AR"></a>
                        </div>
                        <div id="column2">
                          <h2><a href="rooms.php">SRI HARSHA SAI BOYS HOSTEL</a></h2> 
                          <h1>ADDRESS:maisammaguda</h1>
                          <h1>fees:45000</h1>
                          <h1>hostel for: boys</h1>
                        </div>
                        <div id="column3">
                          <h2>HOSTEL FACILITIES</h2> 
                          <h3> FREE WIFI, HOT WATER, 24HRS CURRENT, WASHING MACHINE, WEEKLY TWO TIMES NON-VEG, HOSTEL UNDER CCTV CAMERAS, TELIVISIION FACILITY   </h3>
                        </div>
                      </main>
                      <main id="boxes" >
                        <h2>-------</h2>
                        <div id="column1">
                          <h2>GIRLS HOSTEL</h2> 
                          <a href="#"><img style="height: 80%; width: 100%;" src="https://i.pinimg.com/originals/5c/8d/af/5c8daf6f9caecf0402d947ea115bf8f3.jpg" class="card-img-top" style="height: 58mm; width: 200;" alt="AR"></a>
                        </div>
                        <div id="column2">
                          <h2><a href="rooms.php">REDDYS GIRLS HOSTEL</a></h2> 
                          <h1>ADDRESS:Maisammaguda</h1>
                          <h1>Fees:5500</h1>
                          <h1>hostel for: Girls</h1>
                        </div>
                        <div id="column3">
                          <h2>hOSTEL FACILITIES</h2> 
                          <h3>FREE WIFI, HOT WATER, 24HRS CURRENT, WASHING MACHINE, WEEKLY TWO TIMES NON-VEG, HOSTEL UNDER CCTV CAMERAS, TELIVISIION FACILITY,DAILY SNAKS , EVG TEA WIL BE PROVIDED</h3>
                        </div>
                      </main>
                    </body>
                  </html>