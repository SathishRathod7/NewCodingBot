<!DOCTYPE html>
<html lang="en">
   <head>
      <!-- basic -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title>zon</title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- bootstrap css -->
      <link rel="stylesheet" href="css/bootstrap.min.css">
      <!-- style css -->
      <link rel="stylesheet" href="css/style.css">
      <!-- Responsive-->
      <link rel="stylesheet" href="css/responsive.css">
      <!-- fevicon -->
      <link rel="icon" href="images/fevicon.png" type="image/gif" />
      <!-- Scrollbar Custom CSS -->
      <link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
      <link rel="stylesheet" href="css/owl.carousel.min.css">
      <!-- Tweaks for older IEs-->
      <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
      <link rel="stylesheet" href="https://rawgit.com/LeshikJanz/libraries/master/Bootstrap/baguetteBox.min.css">
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
   </head>
   <!-- body -->
   <body class="main-layout inner_page">
      <!-- loader  -->
      <div class="loader_bg">
         <div class="loader"><img src="images/loading.gif" alt="#"/></div>
      </div>
      <!-- end loader -->
      <!-- header -->
      <div class="header">
         <div class="container-fluid">
            <div class="row d_flex">
               <div class="col-xl-1 col-lg-3 col-sm-2 col logo_section">
                  <div class="full">
                     <div class="center-desk">
                        <div class="logo">
                           <a href="index.php">APNA HOSTEL</a>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-xl-7 col-lg-9 col-md-10 col-sm-12">
                  <nav class="navigation navbar navbar-expand-md navbar-dark ">
                     <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample04" aria-controls="navbarsExample04" aria-expanded="false" aria-label="Toggle navigation">
                     <span class="navbar-toggler-icon"></span>
                     </button>
                     <div class="collapse navbar-collapse" id="navbarsExample04">
                        <ul class="navbar-nav mr-auto">
                           <li class="nav-item ">
                              <a class="nav-link" href="index.php">Home</a>
                           </li>
                           <li class="nav-item">
                              <a class="nav-link" href="about.php">About</a>
                           </li>
                           <li class="nav-item">
                              <a class="nav-link" href="service.php">Service</a>
                           </li>
                           <li class="nav-item active">
                              <a class="nav-link" href="testimonial.php">WE ACCOMODATE</a>
                           </li>
                           <li class="nav-item">
                              <a class="nav-link" href="blog.php">TESTIMONIAL</a>
                           </li>
                           <li class="nav-item">
                              <a class="nav-link" href="contact.php">Contact Us</a>
                           </li>
                           <li class="nav-item">
                              <a class="nav-link" style="background: transparent;" href="Javascript:void(0)"><i class="fa fa-search"></i></a>
                           </li>
                        </ul>
                     </div>
                  </nav>
               </div>
               <div class="col-md-4 re_no">
                  <ul class="infomaco">
                     <li><i class="fa fa-phone" aria-hidden="true"></i> +91 8340023470</li>
                     <li><a href="Javascript:void(0)"><i class="fa fa-envelope-o" aria-hidden="true"></i> sunilmaug@gmail.com</a></li>
                  </ul>
               </div>
            </div>
         </div>
      </div>
      <!-- end header inner -->
      <!-- section blue_bg -->
      <div class="section blue_bg">
         <div class="container">
            <div class="row">
               <!-- testimonial section -->
               <div class=" col-md-12">
                  <div class="testimonial">
                     <div class="row">
                        <div class="col-md-12">
                           <div class="titlepage text_align_left">
                              <h2>we accomodate</h2>
                           </div>
                        </div>
                     </div>
                     <div class="row">
                        <div class="col-md-12">
                           <div id="myCarousel" class="carousel slide testimonial_Carousel " data-ride="carousel">
                              <ol class="carousel-indicators">
                                 <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                                 <li data-target="#myCarousel" data-slide-to="1"></li>
                                 <li data-target="#myCarousel" data-slide-to="2"></li>
                              </ol>
                              <div class="carousel-inner">
                                 <div class="carousel-item active">
                                    <div class="container">
                                       <div class="carousel-caption ">
                                          <div class="row">
                                             <div class="col-md-12">
                                                <div class="testimonial_box text_align_left">
                                                   <p>When you are in India, one thing you cannot live without is adjustments! More often than not, you will end up having a roommate in your hostel. This means that you will have to adjust and manage each other’s quirks, personal space, etc. And in return, you will receive an everlasting friendship.</p>
                                                </div>
                                             </div>
                                             <div class="col-md-12">
                                                <div class="testimonial_pro">
                                                   <figure><img src="images/test_pro.jpg" alt="#"/></figure>
                                                   <h3>Mark Jonson <br><span class="cust">Customre</span></h3>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="carousel-item">
                                    <div class="container">
                                       <div class="carousel-caption">
                                          <div class="row">
                                             <div class="col-md-12">
                                                <div class="testimonial_box text_align_left">
                                                   <p>uffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going touffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going touffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to</p>
                                                </div>
                                             </div>
                                             <div class="col-md-12">
                                                <div class="testimonial_pro">
                                                   <figure><img src="images/test_pro.jpg" alt="#"/></figure>
                                                   <h3>Mark Jonson <br><span class="cust">Customre</span></h3>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="carousel-item">
                                    <div class="container">
                                       <div class="carousel-caption">
                                          <div class="row">
                                             <div class="col-md-12">
                                                <div class="testimonial_box text_align_left">
                                                   <p>uffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going touffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going touffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to</p>
                                                </div>
                                             </div>
                                             <div class="col-md-12">
                                                <div class="testimonial_pro">
                                                   <figure><img src="images/test_pro.jpg" alt="#"/></figure>
                                                   <h3>Mark Jonson <br><span class="cust">Customre</span></h3>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                             
                           </div>
                        </div>
                        
                     </div>
                  </div>
               </div>
               <!-- end testimonial section -->
            </div>
         </div>
      </div>
      <!-- end section blue_bg -->
      <!--  footer -->
      
                  
      </footer>
      <!-- end footer -->
      <!-- Javascript files-->
      <script src="js/jquery.min.js"></script>
      <script src="js/bootstrap.bundle.min.js"></script>
      <script src="js/jquery-3.0.0.min.js"></script>
      <!-- sidebar -->
      <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.8.1/baguetteBox.min.js"></script>
      <script src="js/owl.carousel.min.js"></script>
      <script src="js/custom.js"></script>
   </body>
</html>